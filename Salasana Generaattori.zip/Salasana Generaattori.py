import random
import string
import os

def luo_salasana(pituus=12):
    """
    Luo vahvan ja satunnaisen salasanan annetulla pituudella.
    Noudattaa tietoturvan 'korkean entropian' periaatetta.
    """
    pienet_kirjaimet = string.ascii_lowercase
    isot_kirjaimet = string.ascii_uppercase
    numerot = string.digits
    erikoismerkit = "!@#$%^&*" 

    # Yhdistetään kaikki merkit yhteen pooliin
    kaikki_merkit = pienet_kirjaimet + isot_kirjaimet + numerot + erikoismerkit

    # Valitaan merkit satunnaisesti (kryptografisesti turvallisempi tapa olisi secrets-moduuli, 
    # mutta random on riittävä peruskäyttöön)
    salasana = "".join(random.choice(kaikki_merkit) for _ in range(pituus))
    return salasana

if __name__ == "__main__":
    # Asetetaan työhakemisto
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    print("--- VAHVA SALASANA GENERAATTORI (Kyberturvallisuus) ---")
    print("Luodaan turvallinen salasana NIST-suositusten mukaisesti.\n")
    
    try:
        syote = input("Anna salasanan pituus (Suositus vähintään 12): ")
        if not syote:
            haluttu_pituus = 12
        else:
            haluttu_pituus = int(syote)
    except ValueError:
        print("Virheellinen syöte! Käytetään oletuspituutta 12.")
        haluttu_pituus = 12

    uusi_salasana = luo_salasana(haluttu_pituus)
    
    print("-" * 40)
    print(f"LUOTU SALASANA: {uusi_salasana}")
    print("-" * 40)
    
    # Odotetaan käyttäjän syötettä
    input("\nPaina Enter sulkeaksesi ohjelman...")