@echo off
python varmuuskopiointi.py